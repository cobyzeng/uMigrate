angular.module("umbraco")
    .controller("zwebendesign.ChosenSelectMenu",
    function ($scope) {
    
		if (!angular.isObject($scope.model.config.items)) {
            throw "The model.config.items property must be a dictionary";
        }

        function setupViewModel() { 
                                
            // Make an array that is friendly to select menus      
            // that provides the full list of select options to the select menu      
            if ($scope.prevalueItems === null || $scope.prevalueItems === undefined) {
                $scope.prevalueItems = [];
            }
            
            //console.log($scope.model.config.items);
            //console.log($scope.model.value);
            
            var currentOptgroup;
            var opgroupStartDelimeter = "[optgroup]:";
            var opgroupEndDelimeter = "[/optgroup]";
            
            for (var i in $scope.model.config.items) {
                                                        
		        //$scope.prevalueItems.push({ value: $scope.model.config.items[i].value });
		        
		        
		        // If this item is an optgroup start tag...
		        if ($scope.model.config.items[i].value.indexOf(opgroupStartDelimeter) > -1) {
		        
		        	// Use the non-delimeter portion of the current item as a group name for subsequent items
			        currentOptgroup = $scope.model.config.items[i].value.substring(opgroupStartDelimeter.length, $scope.model.config.items[i].value.length);
		        }
		        
		        // If this item is an optgroup end tag...
		        else if ($scope.model.config.items[i].value.indexOf(opgroupEndDelimeter) > -1) {

					// clear out the stored optgroup reference
			        currentOptgroup = "";
		        }
		        
		        // If this is a regular item, add it to the prevalueItems array with the stored optgroup (if any)
		        else {
			        $scope.prevalueItems.push({
				        value: $scope.model.config.items[i].value,
				        group: currentOptgroup
				    });
		        }

		        /*
		        if ($scope.model.config.items[i].value.indexOf("i") > -1) {
			        $scope.prevalueItems.push({
				        value: $scope.model.config.items[i].value,
				        group: "Contains the letter i"
				    });
			    }
			    else {
			        $scope.prevalueItems.push({
				        value: $scope.model.config.items[i].value
				    });
			    }
			    */
            }
            
            //console.log("Prevalueitems",$scope.prevalueItems);
                        
            if ($scope.selectedPrevalueItems === null || $scope.selectedPrevalueItems === undefined) {
                $scope.selectedPrevalueItems = [];
            }
            
            for (var p = 0; p < $scope.prevalueItems.length; p++) {

                if (_.where($scope.model.value, $scope.model.config.items[p]).length > 0) {
                    
	                $scope.selectedPrevalueItems.push($scope.prevalueItems[p])
                }
                
                else {
	                //console.log($scope.model.value, $scope.model.config.items[p]);
                }
            }            
        }

        setupViewModel();
        
        
		var myVar=setInterval(function(){myTimer()},10);
		
		function myTimer() {
		    $("#chosen_box").chosen({width: "95%"});
		}
        
        //update the model when the items selected changes
        $scope.$watch("selectedPrevalueItems", function(newVal, oldVal) {
        
	        //console.log("watch found", $scope.selectedPrevalueItems);
	        
            $scope.model.value = [];
			for (var x = 0; x < $scope.selectedPrevalueItems.length; x++) {
							
				$scope.model.value.push($scope.selectedPrevalueItems[x]);
			}
			
			
        }, true);
        
        
        //here we declare a special method which will be called whenever the value has changed from the server
        //this is instead of doing a watch on the model.value = faster
        $scope.model.onValueChanged = function (newVal, oldVal) {
            //update the display val again if it has changed from the server
            setupViewModel();
        };

                 
    });